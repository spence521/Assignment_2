All you have to do is run the bash script (run.sh)
To do that, do the following:

1. chmod +x run.sh
2. ./run.sh